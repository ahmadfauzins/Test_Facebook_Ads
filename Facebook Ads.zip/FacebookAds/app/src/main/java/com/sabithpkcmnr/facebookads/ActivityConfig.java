package com.sabithpkcmnr.facebookads;

class ActivityConfig {

    //Replace this Adunits IDs with your own Facebook App Adunits
    static String FB_BANNER = "IMG_16_9_APP_INSTALL#793558501471799_800861097408206";
    static String FB_RECTANGLE = "IMG_16_9_APP_INSTALL#793558501471799_804222103738772";
    static String FB_INTERSTITIAL = "IMG_16_9_APP_INSTALL#793558501471799_804227947071521";
    static String FB_REWARD = "IMG_16_9_APP_INSTALL#793558501471799_804228923738090";

}